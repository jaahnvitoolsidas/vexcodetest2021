/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Student                                          */
/*    Created:      Thu Oct 28 2021                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// lift                 motor         2               
// frontl               motor         11              
// backl                motor         12              
// frontr               motor         19              
// backr                motor         20              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;


void drivefwd(float degs)
{
 frontl.setPosition(0, degrees);
 while (frontl.rotation(degrees)< degs){
 frontl.spin(forward);
 backl.spin(forward);
 frontr.spin(forward);
 backr.spin(forward);
 }
frontl.stop();
backl.stop();
frontr.stop();
backr.stop();
} 

void driverev(float degs)
{
 frontl.setPosition(0, degrees);
 while (frontl.rotation(degrees) > degs){
 frontl.spin(reverse);
 backl.spin(reverse);
 frontr.spin(reverse);
 backr.spin(reverse);
 }
frontl.stop();
backl.stop();
frontr.stop();
backr.stop();
}
 
void turnright(int degs)
{
 frontl.setPosition(0, degrees);
 while (frontl.rotation(degrees) < degs){
frontl.spin(forward);
backl.spin(forward);
frontr.spin(reverse);
backr.spin(reverse);
}
frontl.stop();
backl.stop();
frontr.stop();
backr.stop();
}
 
void turnleft(int degs)
{
 frontl.setPosition(0, degrees);
 while (frontl.rotation(degrees) > degs){
frontl.spin(reverse);
backl.spin(reverse);
frontr.spin(forward);
backr.spin(forward);
}
frontl.stop();
backl.stop();
frontr.stop();
backr.stop();
}

void lifting(float degs)
{
 lift.setPosition(0, degrees);
  while (lift.rotation(degrees) < degs){
    lift.spin(forward);
  }
  lift.setVelocity(10,percent);
  lift.spinFor(forward, 800, degrees);
  lift.stop();
}
 
void liftrev(float degs)
{
  while (lift.rotation(degrees) > degs){
    lift.spin(reverse);
  }
  lift.stop();
}


int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  drivefwd(360);
  wait(0.1, seconds);
  turnright(270);
  wait(0.1, seconds);
  lifting(800);
  liftrev(0);
  wait(0.1, seconds);
  turnleft(-270);
  driverev(-300);
  turnright(240);
  drivefwd(100);

  using namespace vex;
}